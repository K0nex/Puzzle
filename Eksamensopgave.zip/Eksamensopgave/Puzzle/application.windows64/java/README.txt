Please refer to http://java.com/licensereadme
